const { SlashCommandBuilder } = require('@discordjs/builders');
const { ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const config = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verifikovatuzivatele')
        .setDescription('Ověření uživatele podle názvu účtu'),

    async execute(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('verification-modal')
            .setTitle('Verifikace Uživatele')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('accountName')
                        .setLabel('Account Name')
                        .setMaxLength(30)
                        .setPlaceholder('Zadejte název účtu')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
    },

    async handleModal(interaction) {
        const accountName = interaction.fields.getTextInputValue('accountName');
        const db = new sqlite3.Database('./verification.sqlite');

        db.serialize(() => {
            db.run(`CREATE TABLE IF NOT EXISTS verification (id INTEGER PRIMARY KEY, accountName TEXT UNIQUE)`);
            db.get(`SELECT accountName FROM verification WHERE accountName = ?`, [accountName], (err, row) => {
                if (row) {
                    interaction.reply({ content: 'Tento účet je již ověřen.', ephemeral: true });
                } else {
                    db.run(`INSERT INTO verification (accountName) VALUES (?)`, [accountName], (err) => {
                        if (err) {
                            interaction.reply({ content: 'Došlo k chybě při ověřování vašeho účtu.', ephemeral: true });
                        } else {
                            const role = interaction.guild.roles.cache.find(r => r.name === config.verificationRole);
                            const member = interaction.member;
                            member.roles.add(role).then(() => {
                                interaction.reply({ content: 'Úspěšně ověřen a role přiřazena!', ephemeral: true });
                            }).catch(err => {
                                interaction.reply({ content: 'Došlo k chybě při přiřazování role.', ephemeral: true });
                            });
                        }
                    });
                }
            });
        });

        db.close();
    }
};
