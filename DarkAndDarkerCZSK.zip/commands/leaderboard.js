const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const { Bet, Counteroffer } = require('../models');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('Zobrazit žebříček nejlepších hráčů podle bilance'),

    async execute(interaction) {
        try {
            const bets = await Bet.findAll();
            const counteroffers = await Counteroffer.findAll();

            let userStats = {};

            const parseGoldValue = (item) => {
                const goldMatch = item.match(/^(\d+(\.\d+)?)([kKgG]?)$/);
                if (goldMatch) {
                    let value = parseFloat(goldMatch[1]);
                    const multiplier = goldMatch[3].toLowerCase();
                    if (multiplier === 'k') {
                        value *= 1000;
                    }
                    return value;
                } else {
                    return null;
                }
            };

            // Process bets
            bets.forEach(bet => {
                const goldValue = parseGoldValue(bet.item);

                if (!userStats[bet.userId]) {
                    userStats[bet.userId] = { username: bet.username, goldBet: 0, goldWon: 0, goldLost: 0 };
                }

                if (goldValue !== null) {
                    userStats[bet.userId].goldBet += goldValue;
                }

                if (bet.isRolled && bet.winner) {
                    if (bet.winner === bet.username) {
                        if (goldValue !== null) {
                            userStats[bet.userId].goldWon += goldValue;
                        }
                    } else {
                        if (goldValue !== null) {
                            userStats[bet.userId].goldLost += goldValue;

                            if (!userStats[bet.winner]) {
                                userStats[bet.winner] = { username: bet.winner, goldBet: 0, goldWon: 0, goldLost: 0 };
                            }
                            userStats[bet.winner].goldWon += goldValue;
                        }
                    }
                }
            });

            // Process counteroffers
            counteroffers.forEach(counteroffer => {
                const bet = bets.find(b => b.id === counteroffer.betId);
                const goldValue = parseGoldValue(counteroffer.counterofferItem);

                if (bet && bet.isRolled && bet.winner === counteroffer.username && goldValue !== null) {
                    if (!userStats[counteroffer.userId]) {
                        userStats[counteroffer.userId] = { username: counteroffer.username, goldBet: 0, goldWon: 0, goldLost: 0 };
                    }

                    userStats[counteroffer.userId].goldWon += goldValue;
                    userStats[bet.userId].goldLost += goldValue;
                }
            });

            // Sort users by balance (goldWon - goldLost)
            let sortedUsers = Object.values(userStats)
                .map(user => ({
                    ...user,
                    goldBalance: user.goldWon - user.goldLost,
                }))
                .sort((a, b) => b.goldBalance - a.goldBalance)
                .slice(0, 10);

            // Create embed message
            const embed = new EmbedBuilder()
                .setTitle('Žebříček nejlepších hráčů podle bilance')
                .setDescription(sortedUsers.map((user, index) => {
                    const balanceText = user.goldBalance >= 0 ? `+${user.goldBalance}g` : `${user.goldBalance}g`;
                    return `${index + 1}. ${user.username} - Bilance: ${balanceText}, Celkem vsazeno: ${user.goldBet}g`;
                }).join('\n'));

            // Send embed message
            await interaction.reply({ embeds: [embed], ephemeral: true });
        } catch (error) {
            console.error('Error fetching leaderboard:', error);
            await interaction.reply({ content: 'Při načítání žebříčku došlo k chybě.', ephemeral: true });
        }
    }
};
